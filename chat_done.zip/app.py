from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:''@localhost/flask_blog'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class BLOGS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    desc = db.Column(db.String(500), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.id} - {self.title}"

@app.route('/', methods=['GET', 'POST'])
def hello_world():
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        blog = BLOGS(title=title, desc=desc)
        db.session.add(blog)
        db.session.commit()
        
    allBlogs = BLOGS.query.all() 
    return render_template('index.html', allBlogs=allBlogs)

@app.route('/show')
def products():
    allBlogs = BLOGS.query.all()
    print(allBlogs)
    return 'this is example page'

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        blog = BLOGS.query.filter_by(id=id).first()
        blog.title = title
        blog.desc = desc
        db.session.commit()
        return redirect("/")
        
    blog = BLOGS.query.filter_by(id=id).first()
    return render_template('update.html', blog=blog)

@app.route('/delete/<int:id>')
def delete(id):
    blog = BLOGS.query.filter_by(id=id).first()
    db.session.delete(blog)
    db.session.commit()
    return redirect("/")

@app.route('/ai_chatbot')
def ai_chatbot_redirect():
    return redirect('http://127.0.0.1:7000/') 

@app.route('/chat_all')
def chat():
    return redirect('http://127.0.0.1:5000/')

if __name__ == "__main__":
    app.run(debug=True, host='127.0.0.1', port=8000)

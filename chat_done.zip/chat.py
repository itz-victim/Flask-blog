from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL
from flask_socketio import SocketIO, join_room, leave_room, send, emit
import bcrypt
import secrets
from datetime import datetime

secret = secrets.token_hex(16)

app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flask_blog'

mysql = MySQL(app)

app.config['SECRET_KEY'] = secret
socketio = SocketIO(app)

# Dictionary to store chat_users' session IDs
active_users = {}

# List to store message history
message_history = []

users = {}

@app.route('/')
def index():
    if 'username' in session:
        return redirect('/chat')
    else:
        return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'username' in session:
        return redirect('/chat')
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username already exists
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM chat_users WHERE username = %s', (username,))
        existing_user = cursor.fetchone()
        cursor.close()

        if existing_user:
            return 'Username already exists. Please choose a different username.'
        else:
            # Hash password
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

            # Insert new user into the database
            cursor = mysql.connection.cursor()
            cursor.execute('INSERT INTO chat_users (username, password) VALUES (%s, %s)', (username, hashed_password))
            mysql.connection.commit()
            cursor.close()

            # Redirect to chat page without taking to login page again
            cursor = mysql.connection.cursor()
            cursor.execute('SELECT * FROM chat_users WHERE username = %s', (username,))
            user = cursor.fetchone()  # Fetch one row from the result
            cursor.close()
            if user:
                if bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
                    session['username'] = username
                    return redirect('/chat')
                else:
                    return 'Invalid username/password combination'
            else:
                return redirect('/login')

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect('/chat')
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM chat_users WHERE username = %s', (username,))
        user = cursor.fetchone()  # Fetch one row from the result
        cursor.close()

        if user:
            if bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
                session['username'] = username
                return redirect('/chat')
            else:
                return 'Invalid username/password combination'
        else:
            return 'User not found'

    return render_template('login.html')

@app.route('/chat')
def chat():
    if 'username' in session:
        return render_template('chat.html', username=session['username'], history=message_history)
    else:
        return redirect('/login')

@app.route('/logout')
def logout():
    if 'username' in session:
        session.pop('username', None)
    return redirect('/login')

@socketio.on('connect')
def handle_connect():
    if 'username' in session:
        active_users[request.sid] = session['username']
        username = session['username']
        room = 'default'
        if room not in users:
            users[room] = []
        users[room].append(username)
        join_room(room)
        
        # Get current time
        join_time = datetime.now().strftime("%Y-%m-%d %I:%M %p")
        
        # Emit a system message with join time
        emit('message', {'name': 'System', 'message': f"{username} has entered the room.", 'time': join_time}, room=room)
        emit('update_members', {'members': users[room]}, room=room)

@socketio.on('disconnect')
def handle_disconnect():
    if 'username' in session:
        username = session['username']
        active_users.pop(request.sid, None)
        room = 'default'
        if room in users and username in users[room]:
            users[room].remove(username)
            leave_room(room)
            
            # Get current time
            leave_time = datetime.now().strftime("%Y-%m-%d %I:%M %p")
            
            # Emit a system message with leave time
            emit('message', {'name': 'System', 'message': f"{username} has left the room.", 'time': leave_time}, room=room)
            emit('update_members', {'members': users[room]}, room=room)

@socketio.on('message')
def handle_message(data):
    sender = session.get('username')
    message_time = datetime.now().strftime("%Y-%m-%d %I:%M %p")  # %I for 12-hour format, %p for AM/PM

    emit('message', {'name': sender, 'message': data['message'], 'time': message_time}, room='default')
    # Append message to message history
    message_history.append({'name': sender, 'message': data['message'], 'time': message_time})

if __name__ == '__main__':
    socketio.run(app, debug=True, host='127.0.0.1', port=5000)

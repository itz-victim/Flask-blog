from flask import Flask, render_template, request, redirect, session
from flask_socketio import SocketIO, emit
import bcrypt
import secrets

secret = secrets.token_hex(16)

app = Flask(__name__)
app.config['SECRET_KEY'] = secret
socketio = SocketIO(app)

# Dictionary to store users' session IDs
active_users = {}

# Dictionary to store user information for signup
users = {}


@app.route('/')
def index():
    if 'username' in session:
        return redirect('/chat')
    else:
        return redirect('/login')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check username and password
        if username in users and bcrypt.checkpw(password.encode('utf-8'), users[username]['password']):
            session['username'] = username
            return redirect('/chat')
        else:
            return render_template('login.html', error='Invalid username or password.')

    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if username already exists
        if username in users:
            return render_template('signup.html', error='Username already exists.')

        # Hash the password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # Store username and hashed password
        users[username] = {'password': hashed_password}

        # Redirect to login page after successful signup
        return redirect('/login')

    return render_template('signup.html')


@app.route('/chat')
def chat():
    if 'username' in session:
        return render_template('chat.html', username=session['username'])
    else:
        return redirect('/login')


@app.route('/logout')
def logout():
    if 'username' in session:
        session.pop('username', None)
    return redirect('/login')


@socketio.on('connect')
def handle_connect():
    if 'username' in session:
        active_users[request.sid] = session['username']


@socketio.on('disconnect')
def handle_disconnect():
    if 'username' in session:
        active_users.pop(request.sid, None)


@socketio.on('message')
def handle_message(data):
    sender = session.get('username')
    emit('message', {'sender': sender, 'message': data['message']}, broadcast=True)


if __name__ == '__main__':
    socketio.run(app, debug=True)

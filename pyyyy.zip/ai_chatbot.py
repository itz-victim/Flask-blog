from flask import Flask, request, jsonify, render_template
import requests
import json
import os

app = Flask(__name__)

API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent'
API_KEY = 'AIzaSyA9fP7X2QU3w6EcldEtViteuiKaSRCkipA'
HISTORY_FILE = 'history.txt'


def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, 'r') as file:
            return json.load(file)
    return []


def save_history(history):
    with open(HISTORY_FILE, 'w') as file:
        json.dump(history, file, indent=4)


def send_to_api(user_input):
    url = f'{API_URL}?key={API_KEY}'
    data = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": user_input}]
            }
        ]
    }
    response = requests.post(url, json=data)
    response_data = response.json()

    model_text = ""
    if response_data.get("candidates"):
        model_text = response_data["candidates"][0]["content"]["parts"][0]["text"]

    return model_text


@app.route('/')
def index():
    return render_template('ai_chatbot.html')


@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_input = request.json.get('message')
    response_text = send_to_api(user_input)
    return jsonify({"response": response_text})


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=7000)

from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL
from flask import jsonify
import bcrypt
import secrets

secret = secrets.token_hex(16)  # Generates a random hexadecimal string of 16 bytes
#print(secret_key)

app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'chatapp'

mysql = MySQL(app)

# Secret Key for Session
app.secret_key = secret

# Routes
@app.route('/')
def index():
    return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hash password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # Insert new user into the database
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO users (username, password) VALUES (%s, %s)', (username, hashed_password))
        mysql.connection.commit()
        cursor.close()

        return redirect('/login')

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()  # Fetch one row from the result
        cursor.close()

        if user:
            if bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):

                session['username'] = username
                return redirect('/chat')
            else:
                return 'Invalid username/password combination'
        else:
            return 'User not found'

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/login')

@app.route('/chat')
def chat():
    if 'username' in session:
        return render_template('chat.html', username=session['username'])
    else:
        return redirect('/login')

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'username' in session:
        message = request.form['message']
        sender_id = get_user_id(session['username'])
        
        # Logic to store the message in the database
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO messages (sender_id, receiver_id, message) VALUES (%s, (SELECT id FROM users WHERE username = %s), %s)', (sender_id, session['username'], message))
        mysql.connection.commit()
        cursor.close()
        
        return jsonify({"status": "success"})
    else:
        return redirect('/login')

# Helper function to get user ID from username
def get_user_id(username):
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT id FROM users WHERE username = %s', (username,))
    user = cursor.fetchone()
    cursor.close()
    return user[0]

# Helper function to get username from user ID
def get_username_from_id(user_id):
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT username FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    cursor.close()
    return user[0]

@app.route('/send_private_message', methods=['POST'])
def send_private_message():
    if 'username' in session:
        receiver_username = request.form['receiver']
        message = request.form['message']
        sender_id = get_user_id(session['username'])
        receiver_id = get_user_id(receiver_username)

        # Logic to store the private message in the database
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO messages (sender_id, receiver_id, message) VALUES (%s, %s, %s)', (sender_id, receiver_id, message))
        mysql.connection.commit()
        cursor.close()

        return jsonify({"status": "success"})
    else:
        return redirect('/login')

# In the Flask application
@app.route('/fetch_all_messages')
def fetch_all_messages():
    # Fetch all messages from the database
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT sender_id, message FROM messages')
    messages = cursor.fetchall()
    cursor.close()
    
    # Format messages for JSON response
    formatted_messages = [{"sender": get_username_from_id(message[0]), "message": message[1]} for message in messages]
    
    return jsonify({"messages": formatted_messages})



if __name__ == '__main__':
    app.run(debug=True, host='192.168.29.190', port=8000)
